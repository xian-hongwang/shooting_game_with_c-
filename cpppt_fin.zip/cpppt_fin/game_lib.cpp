#include "pch.h"
#include "game_lib.h"
#include <math.h>

index_num min(min_arrary input)
{
	index_num output;
	output.min_f = input.f[0];
	output.ind = 0;
	for (int i = 1; i < 5; i++)
	{
		if (input.f[i] < output.min_f)
		{
			output.min_f = input.f[i];
			output.ind = i;
		}
	}
	return output;
}

tracking_data lock_system(profile tank, enemy_profile e[])
{
	min_arrary input;
	index_num ouput;
	tracking_data tk;
	for (int i = 0; i < 5; i++)
	{
		input.f[i] = sqrt((e[i].pos.X - tank.pos.X) * (e[i].pos.X - tank.pos.X) + (e[i].pos.Y - tank.pos.Y) * (e[i].pos.Y - tank.pos.Y));
		if (e[i].enable == 0)
		{
			input.f[i] = 9999;
		}
	}
	ouput = min(input);
	tk.pos.X = e[ouput.ind].pos.X - tank.pos.X;
	tk.pos.Y = e[ouput.ind].pos.Y - tank.pos.Y;
	tk.pos.Theta = atan(tk.pos.Y / tk.pos.X);
	return tk;
}

tracking_data lock_system2(enemy_profile boss, profile tank)
{
	tracking_data tk;
	/*
	int shift_x = 200;
	int shift_y = 400;
	int R_size = 20;
	*/

	tk.pos.X = tank.pos.X - boss.pos.X;
	tk.pos.Y = tank.pos.Y - boss.pos.Y;
	tk.pos.Theta = atan(tk.pos.Y / tk.pos.X);

	return tk;
}


int lev_convert(int exp_list[], int exp)
{
	int level = 0;

	for (int i = 0; i < 5; i++)
	{
		if (exp >= exp_list[i])
		{
			level = i;
		}
	}

	return level + 1;
}

int divide(int a, int b)
{
	int remainder = a % b;
	a -= remainder;
	return int(a / b);
}