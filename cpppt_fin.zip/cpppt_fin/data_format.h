#pragma once
#define obs_num 5
#define wea_num 30
#define bwep_num 30

struct bits
{
	unsigned char hit : 1;
	unsigned char speedup : 1;
	unsigned char sp_disable : 1;
	unsigned char mp_disbale : 1;
	unsigned char freeze : 1;
	unsigned char sp_up : 1;
	unsigned char mp_up : 1;
	//unsigned char hp_up : 1;
};

union byte_bits
{
	bits b;
	unsigned char B;
};

struct position
{
	float X;
	float Y;
	float Theta = 1.57;
};

struct vw
{
	float V;
	float W;
};

struct points
{
	float HP;
	float SP;
	float MP;
	int exp;
	int level;
};

struct profile
{
	char name[20];
	struct position pos;
	struct vw vel;
	struct points point;
	int t;
	union byte_bits status;
};

struct vxy
{
	float Vx;
	float Vy;
};

struct enemy_profile
{
	char name[20];
	struct position pos;
	struct vxy V;
	struct points point;
	union byte_bits status;
	float width = 20;
	bool enable = 1;
	int counter = 30;
	bool showbar = 0;

	bool p_enable = 1;
};


struct weapon_profile
{
	char name[20];
	struct position pos;
	struct points point;
	float Velocity;
	struct vxy V;
	float range;
	int counter;
	float diameter = 20;
	bool enable = 0;
};

struct item_profile
{
	char c;
	struct position pos;
	int counter;
	float diameter = 10;
	bool enable = 0;
};

struct magic_profile
{
	char name[20];
	struct position pos[5][5];
	struct points point;
	float Velocity;
	struct vxy V;
	float range;
	int counter;
	float diameter = 25;
	bool enable = 0;
};
