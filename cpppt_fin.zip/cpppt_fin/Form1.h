//��������
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "data_format.h"
#include "game_lib.h"
#include <time.h>

//function
//////////////////////////////////////////////////////////////////////////////////////////

void initialize(void);              //��l��
void Motion_model(void);            //��ʼҫ�
void plot_HMI(void);                //�e�X��
void collsion_detection(void);      //�I������
void bwep_shot(void);               //boss�l�u�o�g

void Load_profile(void);            //Ū��profile
void text_displayer(void);          //���r��
void save_data(void);               //�s��
void load_data(void);               //Ū��

///////////////////////////////////////////////////////////////////////////////////////////


struct profile tank_profile;              //�إߩZ�J�����structure
struct enemy_profile obs[obs_num];        //�إ�5�ӻ�ê��(�ĤH)�����structure�A��list�x�s
struct enemy_profile boss;                //�إ�BOSS�����structure
struct weapon_profile wea[wea_num];       //�إߪZ�������structure
struct weapon_profile ruf[wea_num];
struct weapon_profile boswep[bwep_num];    //�إ�boss�Z��
struct item_profile item[3];              //�إ߸ɵ��������structure�A��list�x�s
struct tracking_data tk;                  //�إ���w��V��structure
struct magic_profile mag;
struct weapon_profile heal, prot;

bool tracking_enable = 0;
int system_counter = 0;
int exp_list[5] = { 0 , 10 , 25 , 50 , 80 };
float X = 0;
float Y = 0;
float Theta = 1.57;
float V = 0;
float W = 0;
float dt = 0.1;

int wea_count = 0;
//int bwep_shot = 0;


namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Timer^ timer1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::ProgressBar^ progressBar1;
	private: System::Windows::Forms::ProgressBar^ progressBar2;
	private: System::Windows::Forms::ProgressBar^ progressBar3;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::ProgressBar^ progressBar4;
	private: System::Windows::Forms::ProgressBar^ progressBar5;
	private: System::Windows::Forms::ProgressBar^ progressBar6;
	private: System::Windows::Forms::ProgressBar^ progressBar7;
	private: System::Windows::Forms::ProgressBar^ progressBar8;
	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::ProgressBar^ progressBar9;










	protected:
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->progressBar3 = (gcnew System::Windows::Forms::ProgressBar());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->progressBar2 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->progressBar4 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar5 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar6 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar7 = (gcnew System::Windows::Forms::ProgressBar());
			this->progressBar8 = (gcnew System::Windows::Forms::ProgressBar());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->progressBar9 = (gcnew System::Windows::Forms::ProgressBar());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(786, 431);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(70, 52);
			this->button1->TabIndex = 0;
			this->button1->Text = L"S";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(710, 431);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(70, 52);
			this->button2->TabIndex = 1;
			this->button2->Text = L"L";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(786, 487);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(70, 52);
			this->button3->TabIndex = 2;
			this->button3->Text = L"B";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(786, 375);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(70, 52);
			this->button4->TabIndex = 3;
			this->button4->Text = L"F";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(862, 431);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(70, 52);
			this->button5->TabIndex = 4;
			this->button5->Text = L"R";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->label6);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->button13);
			this->panel1->Controls->Add(this->button12);
			this->panel1->Controls->Add(this->button11);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->progressBar3);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->progressBar2);
			this->panel1->Controls->Add(this->progressBar1);
			this->panel1->Location = System::Drawing::Point(660, 566);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(288, 292);
			this->panel1->TabIndex = 5;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(126, 17);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(42, 15);
			this->label6->TabIndex = 17;
			this->label6->Text = L"Exp : ";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(206, 17);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(51, 15);
			this->label5->TabIndex = 16;
			this->label5->Text = L"Level : ";
			// 
			// button13
			// 
			this->button13->Location = System::Drawing::Point(192, 209);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(65, 61);
			this->button13->TabIndex = 15;
			this->button13->Text = L"Protect";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &Form1::button13_Click);
			// 
			// button12
			// 
			this->button12->Location = System::Drawing::Point(107, 209);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(65, 61);
			this->button12->TabIndex = 14;
			this->button12->Text = L"Heal";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &Form1::button12_Click);
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(22, 209);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(65, 61);
			this->button11->TabIndex = 13;
			this->button11->Text = L"Damage";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &Form1::button11_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(192, 116);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(28, 15);
			this->label4->TabIndex = 9;
			this->label4->Text = L"MP";
			// 
			// progressBar3
			// 
			this->progressBar3->Location = System::Drawing::Point(22, 108);
			this->progressBar3->Name = L"progressBar3";
			this->progressBar3->Size = System::Drawing::Size(164, 23);
			this->progressBar3->TabIndex = 12;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(192, 87);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(23, 15);
			this->label3->TabIndex = 8;
			this->label3->Text = L"SP";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(19, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(73, 15);
			this->label1->TabIndex = 6;
			this->label1->Text = L"Tank_name";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(192, 58);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(25, 15);
			this->label2->TabIndex = 7;
			this->label2->Text = L"HP";
			// 
			// progressBar2
			// 
			this->progressBar2->Location = System::Drawing::Point(22, 79);
			this->progressBar2->Name = L"progressBar2";
			this->progressBar2->Size = System::Drawing::Size(164, 23);
			this->progressBar2->TabIndex = 11;
			// 
			// progressBar1
			// 
			this->progressBar1->Location = System::Drawing::Point(22, 50);
			this->progressBar1->Name = L"progressBar1";
			this->progressBar1->Size = System::Drawing::Size(164, 23);
			this->progressBar1->TabIndex = 10;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(710, 373);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(70, 52);
			this->button6->TabIndex = 6;
			this->button6->Text = L"Gun";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(865, 373);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(70, 52);
			this->button7->TabIndex = 7;
			this->button7->Text = L"lock";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Form1::button7_Click);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(710, 315);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(70, 52);
			this->button8->TabIndex = 8;
			this->button8->Text = L"Ruffle";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Form1::button8_Click);
			// 
			// progressBar4
			// 
			this->progressBar4->Location = System::Drawing::Point(96, 162);
			this->progressBar4->Maximum = 20;
			this->progressBar4->Name = L"progressBar4";
			this->progressBar4->Size = System::Drawing::Size(100, 23);
			this->progressBar4->TabIndex = 9;
			// 
			// progressBar5
			// 
			this->progressBar5->Location = System::Drawing::Point(96, 217);
			this->progressBar5->Maximum = 20;
			this->progressBar5->Name = L"progressBar5";
			this->progressBar5->Size = System::Drawing::Size(100, 23);
			this->progressBar5->TabIndex = 10;
			// 
			// progressBar6
			// 
			this->progressBar6->Location = System::Drawing::Point(96, 262);
			this->progressBar6->Maximum = 20;
			this->progressBar6->Name = L"progressBar6";
			this->progressBar6->Size = System::Drawing::Size(100, 23);
			this->progressBar6->TabIndex = 11;
			// 
			// progressBar7
			// 
			this->progressBar7->Location = System::Drawing::Point(96, 315);
			this->progressBar7->Maximum = 20;
			this->progressBar7->Name = L"progressBar7";
			this->progressBar7->Size = System::Drawing::Size(100, 23);
			this->progressBar7->TabIndex = 12;
			// 
			// progressBar8
			// 
			this->progressBar8->Location = System::Drawing::Point(96, 362);
			this->progressBar8->Maximum = 20;
			this->progressBar8->Name = L"progressBar8";
			this->progressBar8->Size = System::Drawing::Size(100, 23);
			this->progressBar8->TabIndex = 13;
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(823, 130);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(109, 55);
			this->button9->TabIndex = 14;
			this->button9->Text = L"Save";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Form1::button9_Click_1);
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(823, 207);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(109, 55);
			this->button10->TabIndex = 15;
			this->button10->Text = L"load";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Form1::button10_Click_1);
			// 
			// progressBar9
			// 
			this->progressBar9->Location = System::Drawing::Point(159, 53);
			this->progressBar9->Maximum = 50;
			this->progressBar9->Name = L"progressBar9";
			this->progressBar9->Size = System::Drawing::Size(272, 37);
			this->progressBar9->TabIndex = 16;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(982, 953);
			this->Controls->Add(this->progressBar9);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->progressBar8);
			this->Controls->Add(this->progressBar7);
			this->Controls->Add(this->progressBar6);
			this->Controls->Add(this->progressBar5);
			this->Controls->Add(this->progressBar4);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);

		}

		//��l�]�w
		//�N�Z�J�m���A��ê�����H��
		void initialize(void)
		{
			tank_profile.pos.X = 0;
			tank_profile.pos.Y = 0;
			tank_profile.pos.Theta = 1.57;
			tank_profile.point.exp = 0;
			tank_profile.point.level = 1;

			//�H���M�w�ĤH��l��m�Ϋe�i��V
			srand(time(NULL));
			for (int i = 0; i < 5; i++)
			{
				obs[i].pos.X = rand() % 200 - 100;
				obs[i].pos.Y = rand() % 200 - 100;
				obs[i].V.Vx = rand() % 20 - 10;
				obs[i].V.Vy = rand() % 20 - 10;
				obs[i].point.HP = 20;
				obs[i].counter = 30;
				obs[i].point.exp = 10;
			}

			// boss����m
			boss.pos.X = 0;
			boss.pos.Y = 300;
			boss.point.HP = 50;
			boss.point.exp = 30;
			boss.width = 40;
			boss.p_enable = 0;
			boss.showbar = 0;
			boss.counter = 30;


			// boswep
			for (int i = 0; i < bwep_num; i++)
			{
				boswep[i].enable = 0;
				boswep[i].point.HP = 1;
				boswep[i].range = 1000;
				boswep[i].Velocity = 100;
			}

			//progressbar�w�]�ݤ���
			this->progressBar4->Location = System::Drawing::Point(999, 999);
			this->progressBar5->Location = System::Drawing::Point(999, 999);
			this->progressBar6->Location = System::Drawing::Point(999, 999);
			this->progressBar7->Location = System::Drawing::Point(999, 999);
			this->progressBar8->Location = System::Drawing::Point(999, 999);
			this->progressBar9->Location = System::Drawing::Point(999, 999);

			// weapon(Fire)
			for (int i = 0; i < wea_num; i++)
			{
				wea[i].point.HP = 10;
				wea[i].point.SP = 5;
				wea[i].range = 100;
				wea[i].Velocity = 50;
				wea[i].enable = 0;
			}

			// weapon(Ruffle)
			for (int i = 0; i < wea_num; i++)
			{
				ruf[i].point.HP = 20;
				ruf[i].point.SP = 10;
				ruf[i].range = 200;
				ruf[i].Velocity = 100;
				ruf[i].enable = 0;
			}

			//magic(prot)
			prot.enable = 0;
			prot.pos.Theta = 1.57;
			prot.range = 300;
			//prot.counter = 30;
			prot.point.HP = 20;
			prot.point.MP = 10;

			//item(�ɵ���)
			item[0].pos.X = 50;
			item[0].pos.Y = 0;
			item[1].pos.X = 100;
			item[1].pos.Y = 0;
			item[2].pos.X = 120;
			item[2].pos.Y = 0;
			item[0].c = 'H';
			item[1].c = 'S';
			item[2].c = 'M';
			item[0].enable = 1;
			item[1].enable = 1;
			item[2].enable = 1;

		}

		//��ʼҫ�
		void Motion_model(void)
		{
			if (tracking_enable == 1)
			{
				tk = lock_system(tank_profile, obs); //tk�����e��w��V
				tank_profile.pos.Theta = tk.pos.Theta;
			}
			tank_profile.pos.X = tank_profile.pos.X + tank_profile.vel.V * cos(tank_profile.pos.Theta) * dt;
			tank_profile.pos.Y = tank_profile.pos.Y + tank_profile.vel.V * sin(tank_profile.pos.Theta) * dt;
			tank_profile.pos.Theta = tank_profile.pos.Theta + tank_profile.vel.W * dt;

			//�ĤH��ʼҦ�
			for (int i = 0; i < 5; i++)
			{
				//enable = 1 : �s�b 
				//enable = 0 : ���s�b
				if (obs[i].enable == 1)
				{
					obs[i].pos.X = obs[i].pos.X + obs[i].V.Vx * dt;
					obs[i].pos.Y = obs[i].pos.Y + obs[i].V.Vy * dt;

					//�W�X��ɴN��^��
					if (obs[i].pos.X > 300)
					{
						obs[i].pos.X = 0;
					}
					if (obs[i].pos.X < 0)
					{
						obs[i].pos.X = 300;
					}
					if (obs[i].pos.Y > 300)
					{
						obs[i].pos.Y = 0;
					}
					if (obs[i].pos.Y < 0)
					{
						obs[i].pos.Y = 300;
					}
				}
			}

			//bar��ʼҦ�
			if (obs[0].enable == 0)
			{
				this->progressBar4->Location = System::Drawing::Point(999, 999);
			}
			if (obs[1].enable == 0)
			{
				this->progressBar5->Location = System::Drawing::Point(999, 999);
			}
			if (obs[2].enable == 0)
			{
				this->progressBar6->Location = System::Drawing::Point(999, 999);
			}
			if (obs[3].enable == 0)
			{
				this->progressBar7->Location = System::Drawing::Point(999, 999);
			}
			if (obs[4].enable == 0)
			{
				this->progressBar8->Location = System::Drawing::Point(999, 999);
			}

			if (boss.enable == 0)
			{
				this->progressBar9->Location = System::Drawing::Point(999, 999);
				boss.showbar = 0;
			}

			////
			// boswep motion
			for (int i = 0; i < bwep_num; i++)
			{
				if (boswep[i].enable == 1 && boswep[i].counter > 0)
				{
					boswep[i].pos.X = boswep[i].pos.X + boswep[i].V.Vx;
					boswep[i].pos.Y = boswep[i].pos.Y + boswep[i].V.Vy;
					boswep[i].counter--;
				}
				else
				{
					boswep[i].enable = 0;
				}
			}

			// weapon motion
			for (int i = 0; i < wea_num; i++)
			{
				wea[i].diameter = 20 * tank_profile.point.level * 1.25;
				if (wea[i].enable == 1 && wea[i].counter > 0)
				{
					wea[i].pos.X = wea[i].pos.X + wea[i].V.Vx;
					wea[i].pos.Y = wea[i].pos.Y + wea[i].V.Vy;
					wea[i].counter--;
				}
				else
				{
					wea[i].enable = 0;
				}
			}

			// ruffle motion
			for (int i = 0; i < wea_num; i++)
			{
				ruf[i].diameter = 20 * tank_profile.point.level * 1.25;
				if (ruf[i].enable == 1 && ruf[i].counter > 0)
				{
					ruf[i].pos.X = ruf[i].pos.X + ruf[i].V.Vx;
					ruf[i].pos.Y = ruf[i].pos.Y + ruf[i].V.Vy;
					ruf[i].counter--;
				}
				else
				{
					ruf[i].enable = 0;
				}
			}

			// magic motion
			if (mag.enable == 1 && mag.counter > 0)
			{
				mag.counter--;
			}
			else
			{
				mag.enable = 0;
			}

			//heal motion
			if (heal.enable == 1 && heal.counter > 0)
			{
				heal.counter--;
			}
			else
			{
				heal.enable = 0;
			}

			//prot motion
			if (prot.enable == 1 && prot.counter > 0)
			{
				prot.pos.X = tank_profile.pos.X + 25 * cos(prot.pos.Theta);
				prot.pos.Y = tank_profile.pos.Y + 25 * sin(prot.pos.Theta);
				prot.pos.Theta = prot.pos.Theta + 1.5 * 0.5;
				prot.counter--;
			}
			else
			{
				prot.enable = 0;
			}

		};

		void plot_HMI(void)
		{
			Graphics^ e1 = this->CreateGraphics();
			e1->Clear(Color::WhiteSmoke);
			Pen^ pen_B = gcnew Pen(Color::Blue, 2);        //�ŵ��ʫ׬�2
			Pen^ pen_k = gcnew Pen(Color::Black, 1);       //�µ��ʫ׬�1
			Pen^ pen_k2 = gcnew Pen(Color::Black, 5);      //�µ��ʫ׬�1
			Pen^ pen_B5 = gcnew Pen(Color::Blue, 5);       //�ŵ��ʫ�5
			Pen^ pen_R = gcnew Pen(Color::Red, 5);         //�����ʫ�5
			Pen^ pen_r = gcnew Pen(Color::Red, 3);         //�����ʫ�3
			Pen^ pen_g = gcnew Pen(Color::Green, 30);      //�W�ʺ�
			Pen^ pen_og = gcnew Pen(Color::Orange, 3);     //�ﵧ�ʫ�1.5
			Pen^ pen_G = gcnew Pen(Color::Green, 1);       //�񵧲ʫ׬�1


			int R_size = 20;   //�Z�J����Τj�p
			int grid_width = 400;
			int grid_height = 400;
			int grid_resolution = 1;
			int shift_x = (grid_width / 2); //
			int shift_y = (grid_height)+0;
			int Y_shift = 0;

			////
			// plot robot position 
			int x1 = (tank_profile.pos.X) / grid_resolution;
			int y1 = (tank_profile.pos.Y + Y_shift) / grid_resolution;
			//DrawEllipse : �e���(�C�� �A x�y�� �A y�y�� �A ���b �A �u�b)
			e1->DrawEllipse(pen_B, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);

			int dir_x = 15 * cos(tank_profile.pos.Theta);
			int dir_y = 15 * sin(tank_profile.pos.Theta);
			//DrawLine : �e�u(�C�� �A x�y�а_�I �A y�y�а_�I �A x�y�в��I �A y�y�в��I)
			e1->DrawLine(pen_B, shift_x + 0 + x1, shift_y - y1, shift_x + x1 + 0 + dir_x, shift_y - y1 - dir_y);
			//int a = 0;


			////
			// plot obstacle position 
			for (int i = 0; i < 5; i++)
			{
				if (obs[i].enable == 1)
				{
					x1 = (obs[i].pos.X) / grid_resolution;
					y1 = (obs[i].pos.Y + Y_shift) / grid_resolution;
					//DrawRectangle : �e�x��(�C�� �A x�y�� �A y�y�� �A �� �A �e)
					e1->DrawRectangle(pen_k, shift_x + 0 + x1, shift_y - y1, 20, 20);
				}
			}

			//plot the potions
			for (int i = 0; i < 5; i++)
			{
				if (obs[i].p_enable == 1 && obs[i].enable == 0)
				{
					x1 = (obs[i].pos.X) / grid_resolution;
					y1 = (obs[i].pos.Y + Y_shift) / grid_resolution;
					//DrawRectangle : �e�x��(�C�� �A x�y�� �A y�y�� �A �� �A �e)
					e1->DrawRectangle(pen_G, shift_x + 0 + x1, shift_y - y1, 20, 20);
				}
			}

			//plot the boss
			if (boss.enable == 1)
			{
				x1 = (boss.pos.X) / grid_resolution;
				y1 = (boss.pos.Y + Y_shift) / grid_resolution;
				//DrawRectangle : �e�x��(�C�� �A x�y�� �A y�y�� �A �� �A �e)
				e1->DrawRectangle(pen_k2, shift_x + 0 + x1, shift_y - y1, 40, 40);
			}

			//boswep
			for (int i = 0; i < bwep_num; i++)
			{
				if (boswep[i].enable = 1 && boswep[i].counter > 0)
				{
					R_size = boswep[i].diameter;
					x1 = (boswep[i].pos.X) / grid_resolution;
					y1 = (boswep[i].pos.Y + Y_shift) / grid_resolution;
					e1->DrawEllipse(pen_B5, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
				}
			}


			// weapon
			//gun
			for (int i = 0; i < wea_num; i++)
			{
				if (wea[i].enable == 1 && wea[i].counter > 0)
				{
					R_size = wea[i].diameter;
					x1 = (wea[i].pos.X) / grid_resolution;
					y1 = (wea[i].pos.Y + Y_shift) / grid_resolution;
					e1->DrawEllipse(pen_B5, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
				}
			}

			//ruf
			for (int i = 0; i < wea_num; i++)
			{
				if (ruf[i].enable == 1 && ruf[i].counter > 0)
				{
					R_size = ruf[i].diameter;
					x1 = (ruf[i].pos.X) / grid_resolution;
					y1 = (ruf[i].pos.Y + Y_shift) / grid_resolution;
					e1->DrawEllipse(pen_R, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
				}
			}

			// items
			for (int i = 0; i < 3; i++)
			{
				if (item[i].enable == 1)
				{
					R_size = item[i].diameter;
					x1 = (item[i].pos.X) / grid_resolution;
					y1 = (item[i].pos.Y + Y_shift) / grid_resolution;
					e1->DrawEllipse(pen_B, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
				}
			}

			//magic
			if (mag.enable == 1)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < 5; j++)
					{
						R_size = mag.diameter;
						x1 = (mag.pos[i][j].X) / grid_resolution;
						y1 = (mag.pos[i][j].Y + Y_shift) / grid_resolution;
						e1->DrawEllipse(pen_r, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
					}
				}
			}

			//heal
			if (heal.enable == 1)
			{
				x1 = (tank_profile.pos.X) / grid_resolution;
				y1 = (tank_profile.pos.Y + Y_shift) / grid_resolution;
				e1->DrawEllipse(pen_g, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
			}


			//protection
			if (prot.enable == 1 && prot.counter > 0)
			{
				R_size = prot.diameter;
				x1 = (prot.pos.X) / grid_resolution;
				y1 = (prot.pos.Y + Y_shift) / grid_resolution;

				e1->DrawEllipse(pen_og, shift_x + x1 - R_size / 2, shift_y - y1 - R_size / 2, R_size, R_size);
			}
		};

		//�o�gboss�l�u
		void bwep_shot(void)
		{
			int i = divide(system_counter + 1, 10) % bwep_num;
			boswep[i].enable = 1;

			if (boswep[i].enable == 1)
			{
				boswep[i].pos.X = boss.pos.X;
				boswep[i].pos.Y = boss.pos.Y;
				boswep[i].pos.Theta = lock_system2(boss, tank_profile).pos.Theta;

				boswep[i].V.Vx = boswep[i].Velocity * cos(boswep[i].pos.Theta) * dt;
				boswep[i].V.Vy = boswep[i].Velocity * sin(boswep[i].pos.Theta) * dt;
				boswep[i].counter = int((boswep[i].range / boswep[i].Velocity) * (1 / dt));
			}
		}

		//�I������
		void collsion_detection(void)
		{
			// collsion between tank and obstacles
			for (int i = 0; i < 5; i++)
			{
				//dis���Z�J�P�ĤH���Z��
				float dis = sqrt((tank_profile.pos.X - obs[i].pos.X) * (tank_profile.pos.X -
					obs[i].pos.X) + (tank_profile.pos.Y - obs[i].pos.Y) * (tank_profile.pos.Y - obs[i].pos.Y));

				//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۡA�h�ĤH�����Z�J����
				if (dis < obs[i].width && obs[i].enable == 1)
				{
					tank_profile.point.HP -= obs[i].point.HP;
					obs[i].enable = 0;
				}
			}

			// collsion between tank and boss
			//dis���Z�J�P�ĤH���Z��
			float dis1 = sqrt((tank_profile.pos.X - boss.pos.X) * (tank_profile.pos.X -
				boss.pos.X) + (tank_profile.pos.Y - boss.pos.Y) * (tank_profile.pos.Y - boss.pos.Y));

			//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۡA�h�ĤH�����Z�J����
			if (dis1 < boss.width && boss.enable == 1)
			{
				if (tank_profile.point.HP - boss.point.HP >= 0)
				{
					tank_profile.point.HP -= boss.point.HP;
					boss.showbar = 1;
				}
				else
				{
					tank_profile.point.HP = 0;
					boss.showbar = 1;
				}

				if (boss.enable == 1 && boss.point.HP <= 0)
				{
					boss.enable = 0;
				}
			}

			//collision between tank and bwep
			for (int i = 0; i < bwep_num; i++)
			{
				//dis��tank�Pbwep���Z��
				float dis = sqrt((tank_profile.pos.X - boswep[i].pos.X) * (tank_profile.pos.X - boswep[i].pos.X)
					+ (tank_profile.pos.Y - boswep[i].pos.Y) * (tank_profile.pos.Y - boswep[i].pos.Y));

				if (dis < 20 && boswep[i].enable == 1)
				{
					if (tank_profile.point.HP - boswep[i].point.HP < 0)
					{
						tank_profile.point.HP = 0;
					}
					else
					{
						tank_profile.point.HP -= boswep[i].point.HP;
					}
					//boswep[i].enable = 0;
				}
			}


			// collsion between tank and potions
			for (int i = 0; i < 5; i++)
			{
				//dis���Z�J�P�Ĥ����Z��
				float dis = sqrt((tank_profile.pos.X - obs[i].pos.X) * (tank_profile.pos.X -
					obs[i].pos.X) + (tank_profile.pos.Y - obs[i].pos.Y) * (tank_profile.pos.Y - obs[i].pos.Y));

				if (dis < obs[i].width && obs[i].p_enable == 1 && tank_profile.point.HP <= 95)
				{
					tank_profile.point.HP += 5;
					obs[i].p_enable = 0;
				}

			}


			// collsion between weapon and obstacle
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < wea_num; j++)
				{
					//dis���l�u�P�ĤH���Z��
					float dis = sqrt((wea[j].pos.X - obs[i].pos.X) * (wea[j].pos.X - obs[i].pos.X) + (wea[j].pos.Y - obs[i].pos.Y) * (wea[j].pos.Y - obs[i].pos.Y));

					//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۥB�l�u�٨S�����A�h�l�u�����ĤH����
					if (dis < obs[i].width && obs[i].enable == 1 && wea[j].enable == 1)
					{
						//�ĤH��q���C��0
						if (obs[i].point.HP - wea[j].point.HP < 0)
						{
							obs[i].point.HP = 0;
						}
						else
						{
							obs[i].point.HP -= wea[j].point.HP;
						}

						wea[j].enable = 0; // weapon disappear
						if (obs[i].point.HP <= 0)
						{
							obs[i].enable = 0; // obstacle disappear
						}
					}
				}
			}


			// collsion between ruffle and obstacles
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < wea_num; j++)
				{
					//dis���l�u�P�ĤH���Z��
					float dis = sqrt((ruf[j].pos.X - obs[i].pos.X) * (ruf[j].pos.X - obs[i].pos.X) + (ruf[j].pos.Y - obs[i].pos.Y) * (ruf[j].pos.Y - obs[i].pos.Y));

					//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۥB�l�u�٨S�����A�h�l�u�����ĤH����
					if (dis < obs[i].width && obs[i].enable == 1 && ruf[j].enable == 1)
					{
						//�ĤH��q���C��0
						if (obs[i].point.HP - ruf[j].point.HP < 0)
						{
							obs[i].point.HP = 0;
						}
						else
						{
							obs[i].point.HP -= ruf[j].point.HP;
						}

						ruf[j].enable = 0; // weapon disappear
						if (obs[i].point.HP <= 0)
						{
							obs[i].enable = 0; // obstacle disappear
						}
					}
				}
			}


			// collsion between weapon and boss
			for (int j = 0; j < wea_num; j++)
			{
				//dis���l�u�P�ĤH���Z��
				float dis = sqrt((wea[j].pos.X - boss.pos.X) * (wea[j].pos.X - boss.pos.X) + (wea[j].pos.Y - boss.pos.Y) * (wea[j].pos.Y - boss.pos.Y));

				//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۥB�l�u�٨S�����A�h�l�u�����ĤH����
				if (dis < boss.width && boss.enable == 1 && wea[j].enable == 1)
				{
					//�ĤH��q���C��0
					if (boss.point.HP - wea[j].point.HP < 0)
					{
						boss.point.HP = 0;
					}
					else
					{
						boss.point.HP -= wea[j].point.HP;
					}

					wea[j].enable = 0; // weapon disappear
					boss.showbar = 1;  //show bar

					if (boss.point.HP <= 0)
					{
						boss.enable = 0; // obstacle disappear
					}
				}
			}

			// collsion between ruf and boss
			for (int j = 0; j < wea_num; j++)
			{
				//dis���l�u�P�ĤH���Z��
				float dis = sqrt((ruf[j].pos.X - boss.pos.X) * (ruf[j].pos.X - boss.pos.X) + (ruf[j].pos.Y - boss.pos.Y) * (ruf[j].pos.Y - boss.pos.Y));

				//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۥB�l�u�٨S�����A�h�l�u�����ĤH����
				if (dis < boss.width && boss.enable == 1 && ruf[j].enable == 1)
				{
					//�ĤH��q���C��0
					if (boss.point.HP - ruf[j].point.HP < 0)
					{
						boss.point.HP = 0;
					}
					else
					{
						boss.point.HP -= ruf[j].point.HP;
					}

					ruf[j].enable = 0; // weapon disappear
					boss.showbar = 1;

					if (boss.point.HP <= 0)
					{
						boss.enable = 0; // obstacle disappear
					}
				}
			}


			// collision between tank and items
			for (int i = 0; i < 3; i++)
			{
				//dis���Z�J�P�ɵ������Z��
				float dis = sqrt((tank_profile.pos.X - item[i].pos.X) * (tank_profile.pos.X - item[i].pos.X) +
					(tank_profile.pos.Y - item[i].pos.Y) * (tank_profile.pos.Y - item[i].pos.Y));

				//�ɵ������|30
				if (dis < 15 && item[i].enable == 1)
				{
					switch (item[i].c)
					{
					case 'H':
						if (tank_profile.point.HP < 100)
							tank_profile.point.HP++;
						break;
					case 'S':
						if (tank_profile.point.SP < 100)
							tank_profile.point.SP++;
						break;
					case 'M':
						if (tank_profile.point.MP < 100)
							tank_profile.point.MP++;
						break;
					default:
						break;
					}
				}
			}

			// collision between magic and obstacles
			if (mag.enable == 1)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < 5; j++)
					{
						for (int n = 0; n < 5; n++)
						{
							float dis = sqrt((mag.pos[i][j].X - obs[n].pos.X) * (mag.pos[i][j].X - obs[n].pos.X) +
								(mag.pos[i][j].Y - obs[n].pos.Y) * (mag.pos[i][j].Y - obs[n].pos.Y));

							if (dis < 2 * mag.diameter)
							{
								//�ĤH��q���C��0
								if (obs[n].point.HP - mag.point.HP < 0)
								{
									obs[n].point.HP = 0;
								}
								else
								{
									obs[n].point.HP -= mag.point.HP;
								}

								if (obs[n].point.HP <= 0)
								{
									obs[n].enable = 0;      // obstacle disapear
								}
							}
						}
					}
				}
			}

			// collision between protection and obstacles
			if (prot.enable == 1)
			{
				for (int i = 0; i < 5; i++)
				{
					//dis���Z�J�P�ĤH���Z��
					float dis = sqrt((prot.pos.X - obs[i].pos.X) * (prot.pos.X -
						obs[i].pos.X) + (prot.pos.Y - obs[i].pos.Y) * (prot.pos.Y - obs[i].pos.Y)) - 0.5 * prot.diameter;

					//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۡA�h�ĤH����
					if (dis < obs[i].width && obs[i].enable == 1)
					{
						//�ĤH��q���C��0
						if (obs[i].point.HP - prot.point.HP < 0)
						{
							obs[i].point.HP = 0;
						}
						else
						{
							obs[i].point.HP -= prot.point.HP;
						}

						if (obs[i].point.HP <= 0)
						{
							obs[i].enable = 0;
						}
					}
				}
			}

			// collision between magic and boss
			if (mag.enable == 1)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < 5; j++)
					{
						float dis = sqrt((mag.pos[i][j].X - boss.pos.X) * (mag.pos[i][j].X - boss.pos.X) +
							(mag.pos[i][j].Y - boss.pos.Y) * (mag.pos[i][j].Y - boss.pos.Y));

						if (dis < 2 * mag.diameter)
						{
							//�ĤH��q���C��0
							if (boss.point.HP - mag.point.HP < 0)
							{
								boss.point.HP = 0;
							}
							else
							{
								boss.point.HP -= mag.point.HP;
							}

							boss.showbar = 1;

							if (boss.point.HP <= 0)
							{
								boss.enable = 0;     // boss disapear
							}
						}
					}
				}
			}

			// collision between protection and boss
			if (prot.enable == 1)
			{
				//dis���Z�J�P�ĤH���Z��
				float dis = sqrt((prot.pos.X - boss.pos.X) * (prot.pos.X - boss.pos.X) + (prot.pos.Y - boss.pos.Y) * (prot.pos.Y - boss.pos.Y)) - 0.5 * prot.diameter;

				//�Y�Z��<�ĤH�e��(�Y�I��F)�B�ĤH�٬��ۡA�h�ĤH����
				if (dis < boss.width && boss.enable == 1)
				{
					//�ĤH��q���C��0
					if (boss.point.HP - prot.point.HP < 0)
					{
						boss.point.HP = 0;
					}
					else
					{
						boss.point.HP -= prot.point.HP;
					}

					boss.showbar = 1;

					if (boss.point.HP <= 0)
					{
						boss.enable = 0;
					}
				}
			}

			//�Q������ܦ��3��
			if (obs[0].point.HP >= 0 && obs[0].point.HP < 20)
			{
				if (obs[0].counter > 0)
				{
					this->progressBar4->Location = System::Drawing::Point(96, 162);
					obs[0].counter--;
				}
				else
				{
					this->progressBar4->Location = System::Drawing::Point(999, 999);
				}
			}
			if (obs[1].point.HP >= 0 && obs[1].point.HP < 20)
			{
				if (obs[1].counter > 0)
				{
					this->progressBar5->Location = System::Drawing::Point(96, 217);
					obs[1].counter--;
				}
				else
				{
					this->progressBar5->Location = System::Drawing::Point(999, 999);
				}
			}
			if (obs[2].point.HP >= 0 && obs[2].point.HP < 20)
			{
				if (obs[2].counter > 0)
				{
					this->progressBar6->Location = System::Drawing::Point(96, 262);
					obs[2].counter--;
				}
				else
				{
					this->progressBar6->Location = System::Drawing::Point(999, 999);
				}
			}
			if (obs[3].point.HP >= 0 && obs[3].point.HP < 20)
			{
				if (obs[3].counter > 0)
				{
					this->progressBar7->Location = System::Drawing::Point(96, 315);
					obs[3].counter--;
				}
				else
				{
					this->progressBar7->Location = System::Drawing::Point(999, 999);
				}
			}
			if (obs[4].point.HP >= 0 && obs[4].point.HP < 20)
			{
				if (obs[4].counter > 0)
				{
					this->progressBar8->Location = System::Drawing::Point(96, 362);
					obs[4].counter--;
				}
				else
				{
					this->progressBar8->Location = System::Drawing::Point(999, 999);
				}
			}

			if (boss.point.HP >= 0 && boss.point.HP < 50 && boss.showbar == 1)
			{
				//boss.counter = 30;
				if (boss.counter > 0)
				{
					this->progressBar9->Location = System::Drawing::Point(159, 53);
					boss.counter--;
				}
				else
				{
					this->progressBar9->Location = System::Drawing::Point(999, 999);
					boss.showbar = 0;
					boss.counter = 30;
				}
			}


			//�p�ⵥ��
			tank_profile.point.exp = 0;
			for (int i = 0; i < 5; i++)
			{
				tank_profile.point.exp += !obs[i].enable * obs[i].point.exp;
			}
			tank_profile.point.exp += !boss.enable * boss.point.exp;
			tank_profile.point.level = lev_convert(exp_list, tank_profile.point.exp);
		};

		void Load_profile(void)
		{
			FILE* pFile;
			pFile = fopen("profile.dat", "r");
			fscanf(pFile, "%s", tank_profile.name);
			fscanf(pFile, "%f", &tank_profile.pos.X);
			fscanf(pFile, "%f", &tank_profile.pos.Y);
			fscanf(pFile, "%f", &tank_profile.pos.Theta);
			fscanf(pFile, "%f", &tank_profile.t);
			fscanf(pFile, "%f", &tank_profile.point.HP);
			fscanf(pFile, "%f", &tank_profile.point.SP);
			fscanf(pFile, "%f", &tank_profile.point.MP);
			fclose(pFile);
		};



		void text_displayer(void)
		{
			String^ str = gcnew String(tank_profile.name);
			this->label1->Text = str;
			this->progressBar1->Value = tank_profile.point.HP;
			this->label2->Text = ("HP:" + Convert::ToString(tank_profile.point.HP) + "/100");
			this->progressBar2->Value = tank_profile.point.SP;
			this->label3->Text = ("SP:" + Convert::ToString(tank_profile.point.SP) + "/100");
			this->progressBar3->Value = tank_profile.point.MP;
			this->label4->Text = ("MP:" + Convert::ToString(tank_profile.point.MP) + "/100");
			this->label5->Text = ("Level : " + Convert::ToString(tank_profile.point.level));
			this->label6->Text = ("Exp : " + Convert::ToString(tank_profile.point.exp));

			//�ĤH�̪����
			this->progressBar4->Value = obs[0].point.HP;
			this->progressBar5->Value = obs[1].point.HP;
			this->progressBar6->Value = obs[2].point.HP;
			this->progressBar7->Value = obs[3].point.HP;
			this->progressBar8->Value = obs[4].point.HP;
			this->progressBar9->Value = boss.point.HP;
		};

		//save
		void save_data(void)
		{
			FILE* pFile;
			pFile = fopen("save.dat", "w");
			fprintf(pFile, "%s\n", tank_profile.name);
			fprintf(pFile, "%f\n", tank_profile.pos.X);
			fprintf(pFile, "%f\n", tank_profile.pos.Y);
			fprintf(pFile, "%f\n", tank_profile.pos.Theta);
			fprintf(pFile, "%f\n", tank_profile.t);
			fprintf(pFile, "%f\n", tank_profile.point.HP);
			fprintf(pFile, "%f\n", tank_profile.point.SP);
			fprintf(pFile, "%f\n", tank_profile.point.MP);
			fprintf(pFile, "%f\n", &tank_profile.point.level);
			fprintf(pFile, "%f\n", &tank_profile.point.exp);
			fclose(pFile);
		};

		//load
		void load_data(void)
		{
			FILE* pFile;
			pFile = fopen("save.dat", "r");
			fscanf(pFile, "%s", tank_profile.name);
			fscanf(pFile, "%f", &tank_profile.pos.X);
			fscanf(pFile, "%f", &tank_profile.pos.Y);
			fscanf(pFile, "%f", &tank_profile.pos.Theta);
			fscanf(pFile, "%f", &tank_profile.t);
			fscanf(pFile, "%f", &tank_profile.point.HP);
			fscanf(pFile, "%f", &tank_profile.point.SP);
			fscanf(pFile, "%f", &tank_profile.point.MP);
			fscanf(pFile, "%f", &tank_profile.point.level);
			fscanf(pFile, "%f", &tank_profile.point.exp);
			fclose(pFile);
		};




#pragma endregion
	private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e)
	{
		if (system_counter == 0)
		{
			Load_profile();
			initialize();
		}

		bwep_shot();
		Motion_model();
		collsion_detection();
		plot_HMI();
		text_displayer();
		system_counter++;
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		tank_profile.vel.V = 0;
		tank_profile.vel.W = 0;
	}

	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e)
	{
		tank_profile.vel.W = 0.174 * 10;
	}
	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e)
	{
		tank_profile.vel.V = -5 * 5.5 * tank_profile.point.level;
	}
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e)
	{
		tank_profile.vel.V = 5 * 5.5 * tank_profile.point.level;
	}
	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e)
	{
		tank_profile.vel.W = -0.174 * 10;
	}

		   //�Z�����s
		   //Gun
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e)
	{
		int i = wea_count % 50;
		//��������SP�~��o�g�l�u
		if (tank_profile.point.SP - wea[i].point.SP >= 0)
		{
			wea[i].enable = 1;
			wea[i].pos.X = tank_profile.pos.X;
			wea[i].pos.Y = tank_profile.pos.Y;
			tank_profile.point.SP = tank_profile.point.SP - wea[i].point.SP;
			wea[i].V.Vx = wea[i].Velocity * cos(tank_profile.pos.Theta) * dt * tank_profile.point.level;
			wea[i].V.Vy = wea[i].Velocity * sin(tank_profile.pos.Theta) * dt * tank_profile.point.level;
			wea[i].counter = int((wea[i].range / wea[i].Velocity) * (1 / dt));
		}
		wea_count++;
	}

	private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (tracking_enable == 0)
		{
			tracking_enable = 1;
			button7->Text = "Lock";
		}
		else
		{
			tracking_enable = 0;
			button7->Text = "Unlock";
		}
	}

		   //Ruffle
	private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e)
	{
		int i = wea_count % 50;
		//��������SP�~��o�g�l�u
		if (tank_profile.point.SP - ruf[i].point.SP >= 0)
		{
			ruf[i].enable = 1;
			ruf[i].pos.X = tank_profile.pos.X;
			ruf[i].pos.Y = tank_profile.pos.Y;
			tank_profile.point.SP = tank_profile.point.SP - ruf[i].point.SP;
			ruf[i].V.Vx = ruf[i].Velocity * cos(tank_profile.pos.Theta) * dt * tank_profile.point.level;
			ruf[i].V.Vy = ruf[i].Velocity * sin(tank_profile.pos.Theta) * dt * tank_profile.point.level;
			ruf[i].counter = int((ruf[i].range / ruf[i].Velocity) * (1 / dt));
		}
		wea_count++;
	}

	private: System::Void button9_Click_1(System::Object^ sender, System::EventArgs^ e)
	{
		save_data();
	}

	private: System::Void button10_Click_1(System::Object^ sender, System::EventArgs^ e)
	{
		load_data();
	}

		   //magic
	private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (tank_profile.point.MP >= 30)
		{
			//Trigger magic attack
			//mag.diameter
			mag.enable = 1;
			mag.point.HP = 10;
			mag.point.MP = 5;
			mag.counter = 1; // Keep 0.1 seconds

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					float dx = 5 * mag.diameter * cos(tank_profile.pos.Theta);
					float dy = 5 * mag.diameter * sin(tank_profile.pos.Theta);
					mag.pos[i][j].X = tank_profile.pos.X + dx + mag.diameter * i - 2.5 * mag.diameter + 10;
					mag.pos[i][j].Y = tank_profile.pos.Y + dy + mag.diameter * j - 2.5 * mag.diameter + 10;
				}
			}
			tank_profile.point.MP -= mag.point.MP;
		}
	}

		   //heal
	private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (tank_profile.point.MP >= 5 && tank_profile.point.HP <= 100 - heal.point.HP)
		{
			heal.enable = 1;
			heal.counter = 10;
			heal.point.HP = 5 * tank_profile.point.level * 1;
			heal.point.MP = 1;

			//�Z�J��q���j��100
			if (tank_profile.point.HP + heal.point.HP <= 100)
			{
				tank_profile.point.HP += heal.point.HP;
			}
			else
			{
				tank_profile.point.HP = 100;
			}

			tank_profile.point.MP -= heal.point.MP;
		}
	}

		   //protection
	private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (tank_profile.point.MP >= 10)
		{
			prot.enable = 1;
			prot.counter = 30;
			tank_profile.point.MP -= prot.point.MP;
		}
	}
	};
}
